import java.util.Scanner;


public class NorkPigLatin {

	public static void main(String[] args)
	{
		//import scanner
		Scanner sc = new Scanner(System.in);
		
		//initialize choice
		String choice = "y";
		
		//welcome message
		System.out.println("Welcome to the Pig Latin Translator.");
		
		//if choice is y, do this stuff
		while(!choice.equalsIgnoreCase("n"))
		{
			
			//ask for phrase
			System.out.println("Please enter a phrase to be translated to pig latin.");
			
			//take in phrase and make all lowercase
			String phrase = sc.nextLine().toLowerCase();
			
			//check to be sure the user entered something, and if so do this stuff
			if(!phrase.equals(""))
			{
				System.out.println();
				
				//make an array of the individual words after splitting phrase
				String[] words = phrase.split(" ");
				
				//check to see if each word starts with a vowel
				for (String word : words)
					if (word.startsWith("a") || word.startsWith("e") || word.startsWith("i") || word.startsWith("o") || word.startsWith("u"))
					{
						System.out.print(word + "way" + " ");
					}
				
				//if word starts with a consonant, find the FIRST vowel and take the consonants before it and put them on the end plus ay
					else
					{
						for(int i = 0; i < word.length(); i++)
						{
					            if((word.charAt(i) == 'a') || 
					               (word.charAt(i) == 'e') ||
					               (word.charAt(i) == 'i') || 
					               (word.charAt(i) == 'o') ||
					               (word.charAt(i) == 'u') ||
					               (word.charAt(i) == 'y'))
					            {
						            String frontPart = word.substring(0, i);
					            	word = word.substring(i, word.length());
					            	System.out.print(word + frontPart + "ay ");
					            	
					            	//have to use break or the word will be searched further and if there are more than one vowel
					            	//they will be split again
					            	break;
					            }   
						}	
					}
				System.out.println();
				
				//ask if the user would like to go again
				System.out.println("Would you like to translate another phrase? y/n");
				choice = sc.nextLine();
				}
				else//if nothing was entered, do this
				{
					System.out.println("you must enter a phrase to be translated.");
					System.out.println();
				}
		}
		//close scanner and say goodbye
		sc.close();
		System.out.println("Thanks for dropping by...GoodBye.");
	}
	
}
