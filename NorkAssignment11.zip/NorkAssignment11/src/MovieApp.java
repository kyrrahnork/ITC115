import java.util.ArrayList;
import java.util.Scanner;

public class MovieApp {

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		String choice = "y";
		
		System.out.println("Welcome to the movie app.");

		while(choice.equalsIgnoreCase("y"))
		{
			System.out.println("Please select from the following categories to see what movies we have in that genre:");
			System.out.println();
			System.out.println("animated");
			System.out.println("drama");
			System.out.println("horror");
			System.out.println("musical");
			System.out.println("scifi");
			String category = sc.nextLine();
			System.out.println();
			
			//loop through and grab all titles that match the category
			ArrayList<Movie> movies = MovieDB.getMovies(category);
			for(Movie m : movies)
			{
				//print each title
				System.out.println(m.getTitle());
			}
			System.out.println();
			System.out.println("Would you like to continue? y/n");
			choice = sc.nextLine();
			if(choice.equalsIgnoreCase("n"))
			{
				System.out.println("Thanks for checking us out! Goodbye");
			}
		}
		sc.close();
	}

}
