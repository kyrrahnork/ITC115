import java.util.Scanner;


public class DiceRollerApp {

	public static void main(String[] args)
	{
		//initialize scanner
				Scanner sc = new Scanner(System.in);
				
				//initialize choice variable
				String choice = "y";
				
				//initialize counter
				int counter = 1;
				
				//welcome message
				System.out.println("Welcome to the Dice Roller");
				System.out.println();
				
				//ask if they want to begin
				System.out.println("Would you like to roll the dice? y/n");
				choice = sc.nextLine();
				
				//start counter for first roll
				System.out.println("Roll #" + counter);
				
				//instantiate instance of PairOfDice class
				PairOfDice pair = new PairOfDice();
				
				//call roll method from PairOfDice class
				pair.roll();
				
				//stuff to do while choice is "y"
				while(!choice.equalsIgnoreCase("n"))
				{
					System.out.println("Would you like to roll the dice again? y/n");
					choice = sc.nextLine();
					
					//do this if user wants to roll again
					if (!choice.equalsIgnoreCase("n"))
					{
						counter++;
						System.out.println("Roll #" + counter);
						
						pair.roll();
					}
					
					//if user doesn't want to roll, exit
					else
					{
						break;
					}
				}
				
				//close scanner and say goodbye
				sc.close();
				System.out.println("Thanks for playing, Bye");
	}
}
