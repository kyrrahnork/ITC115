
public class PairOfDice
{
	//private int diceSides;
	
	//initialize variables for value of each die and the sum of the 2
	private int dieValue1;
	private int dieValue2;
	private int diceSum;
	
	//instantiate 2 instances of the class Die, 1 for each die rolled
	Die die1 = new Die();
	Die die2 = new Die();
	
//	public PairOfDice()
//	{
//		//diceSides = 6;
//	}
//	
//	public PairOfDice(int sides)
//	{
//		//diceSides = sides;
//	}
	
	//roll the dice method
	public void roll()
	{
		//call roll method from Die class for each die
		die1.roll();
		die2.roll();
		
		//call methods to return value of each die
		getValue1();
		getValue2();
		getSum();
		
		//print out values of each die
		System.out.println(dieValue1);
		System.out.println(dieValue2);
		
		//print messages if total is 7, or if both dice are 1 or 6
		if(diceSum == 7)
		{
			System.out.println("Craps!");
			System.out.println();
		}
		else if(dieValue1 == 1 && dieValue2 == 1)
		{
			System.out.println("Snake Eyes!");
			System.out.println();
		}
		else if(dieValue1 == 6 && dieValue2 == 6)
		{
			System.out.println("Box Cars!");
			System.out.println();
		}
		else
		{
			System.out.println();
		}
	}
	
	//gets value of first die and assigns it to dieValue1
	public int getValue1()
	{
		dieValue1 = die1.getValue();
		return dieValue1;
	}
	
	//gets value of first die and assigns it to dieValue1
	public int getValue2()
	{
		dieValue2 = die2.getValue();
		return dieValue2;
	}
	
	//calculate the sum of the dice to check if the total is 7
	public int getSum()
	{
		return diceSum = dieValue1 + dieValue2;
	}

}
