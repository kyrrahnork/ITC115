
public class Die
{
	//initialize variables
	private int diceSides;
	private int value;
	
	//set each die to have 6 sides
	public Die()
	{
		diceSides = 6;
	}
	
	//pass number of die sides to variable called sides
	public Die(int sides)
	{
		diceSides = sides;
	}
	
	//come up with a random number between 1-6
	public void roll()
	{
		value = (int)(Math.random() * diceSides + 1);
	}
	
	//return the random number
	public int getValue()
	{
		return value;
	}
}
