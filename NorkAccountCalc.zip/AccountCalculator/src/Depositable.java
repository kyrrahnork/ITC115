
public interface Depositable {

	double deposit(double amount);

}
