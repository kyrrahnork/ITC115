import java.text.NumberFormat;

public class CheckingAccount extends Account{
	private double monthlyFee = 1;
	
	
	public double getMonthlyFee(){
		return monthlyFee;	
	}
	
	public void setMonthlyFee(double monthlyFee){
		this.monthlyFee = monthlyFee;
	}
	public double subtractMonthlyFee(){
		balance = balance-monthlyFee;
		return balance;
	}
	
	public String getMonthlyFeeFormatted(){
		
		NumberFormat currency = NumberFormat.getCurrencyInstance();
		subtractMonthlyFee();
		return "Monthly Fees" + "\n" 
				+ "Checking fee: " + currency.format(monthlyFee);
	}
	
}
