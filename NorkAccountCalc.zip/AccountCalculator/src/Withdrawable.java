
public interface Withdrawable {
	double withdraw(double amount);
}
