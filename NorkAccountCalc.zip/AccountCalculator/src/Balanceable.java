
public interface Balanceable {
	double getBalance();
	void setBalance (double amount);
}
