import java.util.Scanner;

public class AccountApp {
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		CheckingAccount ca = new CheckingAccount();
		String choice ="y";
		
		System.out.println("Welcome to the Account calculator!");
		System.out.println();
 	
		System.out.println("Starting Balance");
     	System.out.println("Checking: " + ca.getBalanceFormatted());     	
     	System.out.print("Would you like to begin? (y/n): ");
     	choice = sc.nextLine();
     	System.out.println();
     	
     	
     	while (choice.equalsIgnoreCase("y"))
     	{
     		
	     	System.out.print("Would you like to make a withdrawal or deposit? (w/d): ");
		    String transaction = sc.nextLine();			    
		    
	     	if (transaction.equalsIgnoreCase("w")){
	     		System.out.println("Enter your withdrawal");
	     		System.out.print("Amount: $");
	     		double amount = Double.parseDouble(sc.nextLine());
	     		if(amount < ca.getBalance()){
	     			ca.withdraw(amount);
	     		}
	     		else{
	     			System.out.println("You do not have sufficient funds to withdraw this amount!");
	     		}
	     		
	     	}
	     	else if (transaction.equalsIgnoreCase("d")){
	     		System.out.println("Enter your deposit");
	     		System.out.print("Amount: $");
	     		double amount = Double.parseDouble(sc.nextLine());
	     		
	     		if(amount <= 10000){
	     			ca.deposit(amount);
	     		}
	     		else{
	     			System.out.println("You can only make deposits up to $10,000!");
	     		}
	     	}
	     	else{
	     		System.out.println("You did not enter a valid choice.");
	     		break;
	     	}   	
	     	
	     	System.out.print("Continue? (y/n): ");
	     	choice = sc.nextLine();
	     	System.out.println();	
     	}

    	System.out.println(ca.getMonthlyFeeFormatted());
    	System.out.println("Final Balance");
    	System.out.println(ca.getBalanceFormatted());
    	
     	System.out.println();
    	System.out.println("Thank you for stopping by!");
        sc.close();
		
	}
}
